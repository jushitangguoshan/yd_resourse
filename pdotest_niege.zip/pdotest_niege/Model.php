<?php
//require_once "MySQLPDO.php";
//基础模型类
class Model extends \MySQLPDO{

    protected static $db;
    #数据库表名
    protected $table='message';
	//查找数据
	public function select($fields, $data, $mode='fetchAll')
    {
		$fields = str_replace(',', '`,`', $fields);
		$where = implode(' AND ', self::_fieldsMap(array_keys($data)));
		$sql="SELECT `$fields` FROM `$this->table` WHERE $where";
		return $this->$mode($sql, $data);
	}
	#拼接sql----》where 条件语句
    protected static function _fieldsMap($data)
    {
        $newDate=[];
        #查询全部数据
        if( empty($data) ){
            return ['id'=>"id>0"];
        }
        foreach( $data as $key=>$value){
            $newDate["`".$value."`"] ="`".$value."`"."=:".$value;
        }
        //var_dump($newDate);die;
        return $newDate;
    }
    #增加数据
    public function insert($fields, $data, $mode='exec')
    {
        //$sql="insert into jk_dingdan (name,price,des) values(:name,:price,:des)";
        $fields = str_replace(',', '`,`', $fields);
        $values=implode(",",self::_valueMap(array_keys($data)));
        $sql="insert into {$this->table} (`$fields`) values({$values})";
        return $this->$mode($sql,$data);
    }
    public static function _valueMap($data)
    {
        $newDate=[];
        foreach( $data as $key=>$value){
            $newDate["`".$value."`"] =":".$value;
        }
        //var_dump($newDate);die;
        return $newDate;
    }

    #修改留言
	public function update($fields,$data, $mode='exec')
    {
        $where = implode(' AND ', self::_fieldsMap(array_keys($data)));
        $values=implode(" , ",self::_fieldsMap(array_keys($fields)));
        $sql="update `$this->table` set $values where $where";
        return $this->$mode($sql, array_merge($fields,$data));
    }
    #删除留言
    public function delete($data,$mode='exec')
    {
        $where=$where = implode(' AND ', self::_fieldsMap(array_keys($data)));
        $sql="delete from `$this->table` where $where";
        return $this->$mode($sql,$data);
    }
}
//$model=new Model();

                //select--查询
//$res=$model->select("id,user_name,p_time,imgs,cont,state",[]);
//var_dump($res);die;

                 //insert--id不能重复
//$res=$model->insert("id,name,price,des",["id"=>6,'name'=>"messboard",'price'=>999,'des'=>"留言测试"]);
//var_dump($res);


            //update--只能通过id 取修改【id不能更改】-----《未完》
//$sql="update jk_dingdan set name='apple2' where id=1";
//$res=$model->update(['user_message'=>'qqqqq','user_mood'=>'qqqq'],["id"=>5]);



//$sql="delete from jk_dingdan where id=9";
//$res=$model->delete(['id'=>5]);
//var_dump($res);
