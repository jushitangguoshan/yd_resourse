<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/22 0022
     * Time: 下午 7:59
     */
    class AutoLoadClass
    {
        public static function start()
        {
            #自动加载类名
            spl_autoload_register([__CLASS__,"load"]);
        }
        public static function load($className)
        {
            $className = PATH.DIRECTORY_SEPARATOR.$className.'.php';
            $className=str_replace("\\","/",$className);
            //echo $className;die;
            require_once $className;
        }
    }