<?php
    //echo __DIR__."<hr>".__FILE__;
    //header("content-type:text/html;charset=utf-8");
    #引入自动加载class
    session_start();
    define("PATH",__DIR__);
    require_once "AutoLoadClass.php";
    \AutoLoadClass::start();
     #错误、异常处理

    ini_set('display_errors',1);
    error_reporting(E_ALL);
    \error\Error::start();

    if(  !isset($_GET['ope']) )exit;
    $ope=$_GET['ope'];
//try{
    switch($ope){
        case "init":
            $data=(new \Model())->select("id,user_name,create_time,user_mood,user_message,message_status",['message_status'=>1],"fetchAll");
            echo json_encode(['message'=>"初始化成功",'data'=>$data]);
            break;
        case "add_msgboard":
            #insert----》数据处理
            $getData=getInsertData();
            #开启事务
            (new \Model())->startTrans();
            $res=(new \Model())->insert("user_name,create_time,user_mood,user_message,message_status",$getData);
            if(!$res){
                #回滚
                (new \Model())->rollBack();
                echo json_encode(['message'=>"发布失败",'data'=>$res]);
            }
            #提交事务
            (new \Model())->commit();
            echo json_encode(['message'=>"发布成功",'data'=>$res]);
            break;
        case "altInit_msgboard":
            $id=$_GET['index'];
            $data=(new \Model())->select("id,user_name,create_time,user_mood,user_message,message_status",['message_status'=>1,'id'=>$id]);
            echo json_encode(['message'=>"初始化成功",'data'=>$data[0]]);
            break;
        case "del_msgboard":
            $id=$_GET['index'];
            #开启事务
            (new \Model())->startTrans();
            $res=(new \Model())->update(['message_status'=>0],['id'=>$id]);
            if(!$res){
                #回滚
                (new \Model())->rollBack();
                echo json_encode(['message'=>"删除失败",'data'=>$res]);
            }
            #提交事务
            (new \Model())->commit();$this->rollBack();
            echo json_encode(['message'=>"删除成功",'data'=>$res]);
            break;
        case "alt_msgboard":
            #update--->数据处理
            $getAltData=getUpdataData();
            #开启事务
            (new \Model())->startTrans();
            $res=(new \Model())->update($getAltData,['id'=>$_POST['user_id']]);
            if(!$res){
                #回滚
                (new \Model())->rollBack();
                echo json_encode(['message'=>"修改失败",'data'=>$res]);
            }
            #提交事务
            (new \Model())->commit();
            echo json_encode(['message'=>"修改成功",'data'=>$res]);
            break;
    }
//}catch(Exception $e){
//    var_dump($e);
//}
#获取留言板数据内容
function getInsertData(){
    //数据获取
    $user_name = empty($_POST['user_name']) ? isNull("用户名") :  $_POST['user_name'] ;
    $user_message = empty($_POST['user_message']) ? isNull("留言内容") : $_POST['user_message'];
    $user_mood = empty($_POST['user_mood']) ? isNull("当前心情") : implode(",",$_POST['user_mood']);
    $user_code = empty($_POST['user_code']) ? isNull("验证码") : $_POST['user_code'];
    $time=time();
    #判断验证码
    if( !handleYzm($user_code) ){
        //抛出异常
        throw new \error\ErrorException("验证码错误",301);
    }
    return ["user_name"=>$user_name,"create_time"=>$time,'user_mood'=>$user_mood,"user_message"=>$user_message,'message_status'=>1];
}
#更新数据---》判断
function getUpdataData(){
    //数据获取
    $user_name = empty($_POST['user_name']) ? isNull("用户名") :  $_POST['user_name'] ;
    $user_message = empty($_POST['user_message']) ? isNull("留言内容") : $_POST['user_message'];
    $user_mood = empty($_POST['user_mood']) ? isNull("当前心情") : implode(",",$_POST['user_mood']);
    $time=time();
    return ["user_name"=>$user_name,"create_time"=>$time,'user_mood'=>$user_mood,"user_message"=>$user_message,'message_status'=>1];
}
#发不留言---》判断是否为空
function isNull($type){
    //抛出异常
    throw new \error\ErrorException($type."不能为空",003);
}
#判断验证码
function handleYzm($yzm){
    if(isset($_SESSION['authnum_session']) && $_SESSION['authnum_session']===$yzm ){
        return true;
    }
    return false;
}