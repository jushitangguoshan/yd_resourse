<?php
//PDO MySQL类
class MySQLPDO
{
	//保存PDO实例
	protected static $db;
	/**
	 * 通过预处理方式执行SQL
	 * @param string $sql 执行的SQL语句模板
	 * @param array $data 数据部分
	 * @return object PDOStatement
	 */
	public function __construct()
    {
        try{
            $dbnm="mysql:host=localhost;dbname=my_test_db";
            #PDO::ATTR_PERSISTENT=>true---------实现持久化连接，
            self::$db=new \PDO($dbnm,"root","root",[PDO::ATTR_PERSISTENT=>true]);
           // self::$db->setAttribute(self::$db->ATTR_ERRMODE,self::$db->ERRMODE_WARNING);//设置错误模式
        }catch(Exception $e){
            throw new \error\Exception("数据库连接失败(__construct())",303);
        }

    }
    # 执行一条SQL语句，返回一个PDOStatement对象
	public function query($sql, $data=[]){
        $stmt=self::$db->prepare($sql);
        $res=$stmt->execute($data);
       if( !$res ){
           throw new \error\ErrorException("sql查询语句错误或查询到0条数据",303);
       }
       return $res;
    }
	

   //执行SQL-写操作（支持批量操作，返回受影响的行数）
	public function exec($sql, $data=[]){
	    #开启事务
        $stmt=self::$db->prepare($sql);
        $stmt->execute($data);
       // var_dump($sql,$data,$stmt);die;
        #上句ssql的影响 行数
        $rows=$stmt->rowCount();
        return $rows;
    }
	//取得一行结果
	public function fetchRow($sql, $data=[]){
        $stmt=self::$db->prepare($sql);
        //execute():执行预处理语句
        $stmt->execute($data);
        //var_dump($stmt->execute());
        $row=$stmt->fetch();
        return  $row;
    }
	//取得所有结果
	public function fetchAll($sql, $data=[]){
	    //pdo暂存
        $pdo=self::$db;
        $stmt=self::$db->prepare($sql);
        //execute():执行预处理语句
        $stmt->execute($data);
       // var_dump($sql,$data,$stmt);die;
        return ($stmt->fetchAll($pdo::FETCH_ASSOC));
    }
	
	//取得一列结果
	public function fetchColumn($sql, $data=[]){
        $stmt=self::$db->prepare($sql);
        //execute():执行预处理语句
        $stmt->execute($data);
        //var_dump($stmt->execute());
        //var_dump($stmt->fetchColumn());
        return $stmt->fetchColumn();
    }
	
	//最后插入的ID
	public function lastInsertId(){
        return self::$db->lastInsertId();
    }
	//事务处理-启动
	public function startTrans(){
	    self::$db->beginTransaction();
    }
	//事务处理-提交
	public function commit(){
	    self::$db->commit();
    }
	//事务处理-回滚
	public function rollBack(){
	    self::$db->rollback();
    }
}
?>