<?php
    $page=new AutoPages(10,100);
    class AutoPages
    {
      protected $number;//每页显示数据
        protected $totalCount;//总共有多少数据
        protected $page;//当前页数
        protected $totalPage;//总页数
        protected $url;//当前url
        public function __construct($number,$totalCount)
        {
            $this->number=$number;
            $this->totalCount=$totalCount;
            $this->totalPage=$this->getTotalPage();
            $this->page=$this->getPage();
            $this->url=$this->getURL();
        }
        protected function getURL()
        {
            $scheme=$_SERVER['REQUEST_SCHEME'];//获取协议名
            $host=$_SERVER['SERVER_NAME'];//得到主机名
            $port=$_SERVER['SERVER_PORT'];//得到端口号
            $uri=$_SERVER['REQUEST_URI'];//得到路径和请求字符串
            #重新拼接uri
            $uriArr=parse_url($uri);//文件名+后面所带参数转换为键值对模式
            $path=$uriArr['path'];//路径名 例：/AutoPages.php

            if( !empty($uriArr['query']) ){
                parse_str($uriArr['query'],$array);//将第一个参数转为关联数组array;
                unset($array['page']);//清除$array中的'page'键值对
                $query=http_build_query($array);//将剩下的参数拼接成请求字符串
                if( $query != ""){
                    $path .= "?".$query;
                }
            }
            // echo $scheme."<hr>";echo $host."<hr>";echo $port."<hr>"; echo $path."<hr>";
            // var_dump($scheme."://".$host.":".$port.$path);die;
            return $scheme."://".$host.":".$port."/".$path;
            
        }
        #获取总页数
        protected function getTotalPage()
        {
            return ceil($this->totalCount/$this->number);
        }
        #获取当前页码
        protected function getPage()
        {
            if( empty( $_GET['page'] )){
                $page = 1;
            }else if( $_GET['page'] > $this->totalPage ){
                $page = $this->totalPage;
            }else if( $_GET['page'] < 1 ){
                $page = 1;
            }else{
                $page = $_GET['page'];
            }
            return $page;
        }
    }



























//    /**
//     * Created by PhpStorm.
//     * User: Administrator
//     * Date: 2019/2/25 0025
//     * Time: 下午 4:08
//     */
///* * *********************************************
// * @类名:   page
// * @参数:   $myde_total - 总记录数
// *          $myde_size - 一页显示的记录数
// *          $myde_page - 当前页
// *          $myde_url - 获取当前的url
// * @功能:   分页实现
// */
//header("content-type:text/html;charset=utf-8");
//class AutoPages {
//    private $myde_total;          //总记录数
//    private $myde_size;           //一页显示的记录数
//    private $myde_page;           //当前页
//    private $myde_page_count;     //总页数
//    private $myde_i;              //起头页数
//    private $myde_en;             //结尾页数
//    private $myde_url;            //获取当前的url
//    /*
//     * $show_pages
//     * 页面显示的格式，显示链接的页数为2*$show_pages+1。
//     * 如$show_pages=2那么页面上显示就是[首页] [上页] 1 2 3 4 5 [下页] [尾页]
//     */
//    private $show_pages;
//
//    public function __construct($myde_total = 1, $myde_size = 1, $myde_page = 1, $myde_url, $show_pages = 2) {
//        $this->myde_total = $this->numeric($myde_total);
//        $this->myde_size = $this->numeric($myde_size);
//        $this->myde_page = $this->numeric($myde_page);
//        $this->myde_page_count = ceil($this->myde_total / $this->myde_size);
//        $this->myde_url = $myde_url;
//        if ($this->myde_total < 0)
//            $this->myde_total = 0;
//        if ($this->myde_page < 1)
//            $this->myde_page = 1;
//        if ($this->myde_page_count < 1)
//            $this->myde_page_count = 1;
//        if ($this->myde_page > $this->myde_page_count)
//            $this->myde_page = $this->myde_page_count;
//        $this->limit = ($this->myde_page - 1) * $this->myde_size;
//        $this->myde_i = $this->myde_page - $show_pages;
//        $this->myde_en = $this->myde_page + $show_pages;
//        if ($this->myde_i < 1) {
//            $this->myde_en = $this->myde_en + (1 - $this->myde_i);
//            $this->myde_i = 1;
//        }
//        if ($this->myde_en > $this->myde_page_count) {
//            $this->myde_i = $this->myde_i - ($this->myde_en - $this->myde_page_count);
//            $this->myde_en = $this->myde_page_count;
//        }
//        if ($this->myde_i < 1)
//            $this->myde_i = 1;
//    }
//
//    //检测是否为数字
//    private function numeric($num) {
//        if (strlen($num)) {
//            if (!preg_match("/^[0-9]+$/", $num)) {
//                $num = 1;
//            } else {
//                $num = substr($num, 0, 11);
//            }
//        } else {
//            $num = 1;
//        }
//        return $num;
//    }
//
//    //地址替换
//    private function page_replace($page) {
//        return str_replace("{page}", $page, $this->myde_url);
//    }
//
//    //首页
//    private function myde_home() {
//        if ($this->myde_page != 1) {
//            return "<a href='" . $this->page_replace(1) . "' title='首页'>首页</a>";
//        } else {
//            return "<p>首页</p>";
//        }
//    }
//
//    //上一页
//    private function myde_prev() {
//        if ($this->myde_page != 1) {
//            return "<a href='" . $this->page_replace($this->myde_page - 1) . "' title='上一页'>上一页</a>";
//        } else {
//            return "<p>上一页</p>";
//        }
//    }
//
//    //下一页
//    private function myde_next() {
//        if ($this->myde_page != $this->myde_page_count) {
//            return "<a href='" . $this->page_replace($this->myde_page + 1) . "' title='下一页'>下一页</a>";
//        } else {
//            return"<p>下一页</p>";
//        }
//    }
//
//    //尾页
//    private function myde_last() {
//        if ($this->myde_page != $this->myde_page_count) {
//            return "<a href='" . $this->page_replace($this->myde_page_count) . "' title='尾页'>尾页</a>";
//        } else {
//            return "<p>尾页</p>";
//        }
//    }
//
//    //输出
//    public function myde_write($id = 'page') {
//        $str = "<div id=" . $id . ">";
//        $str.=$this->myde_home();
//        $str.=$this->myde_prev();
//        if ($this->myde_i > 1) {
//            $str.="<p class='pageEllipsis'>...</p>";
//        }
//        for ($i = $this->myde_i; $i <= $this->myde_en; $i++) {
//            if ($i == $this->myde_page) {
//                $str.="<a href='" . $this->page_replace($i) . "' title='第" . $i . "页' class='cur'>$i</a>";
//            } else {
//                $str.="<a href='" . $this->page_replace($i) . "' title='第" . $i . "页'>$i</a>";
//            }
//        }
//        if ($this->myde_en < $this->myde_page_count) {
//            $str.="<p class='pageEllipsis'>...</p>";
//        }
//        $str.=$this->myde_next();
//        $str.=$this->myde_last();
//        $str.="<p class='pageRemark'>共<b>" . $this->myde_page_count .
//            "</b>页<b>" . $this->myde_total . "</b>条数据</p>";
//        $str.="</div>";
//        return $str;
//    }
//}
//
//    $page=new AutoPages(50,10,1,"www.xhmb.com/AutoPages.php?page=1",2);
//    echo $page->myde_write(1);