<?php
/**
 * 文件说明
 * User: 作者
 * Date: 2019/2/21
 * Time: 17:02
 */
header('content-type:text/html;charset=utf-8');
require_once "exception/DaseException.php";
require_once "exception/ErrorException.php";
require_once "exception/NotIntTypeException.php";
require_once "exception/EmptyException.php";
require_once "functions.php";

# 验证是否是ajax请求
    if( !isAjax() ){
        header("location:https://www.baidu.com");exit;
    }
# 错误显示开关
    ini_set("display_errors",0);
# 错误报告设置
    error_reporting(E_ALL);
# 日志路径定义
    define("LOGS",dirname(__FILE__).DIRECTORY_SEPARATOR."logs".DIRECTORY_SEPARATOR."err.log");
#设置时区
    date_default_timezone_set("PRC");
# 错误处理和异常处理
    require_once 'tp/Error.php';
    \tp\Error::start();
    //echo $a;  //$a未定义 出现notice
    //demo(); // 未定义函数，致命错误
# 业务逻辑判断
if( !isset($_GET['order_id']) || empty($_GET['order_id'])  ){
    throw new \exception\EmptyException();
}
# 参数是正整型
$id = $_GET['order_id'];
if( preg_match("/[^0-9]/",$id) ){  //使用正则表达式校验
    throw new \exception\NotIntTypeException();
}
#判断id 是否有效
$data = require_once 'database.php';
if( !isset($data[$id]) ){
    throw new \exception\ErrorException("无效的id",'409');
}
echo json_encode(['message'=>"查询成功","date"=>"hello word"]);


