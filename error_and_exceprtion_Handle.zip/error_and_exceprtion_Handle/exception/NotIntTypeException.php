<?php
    namespace exception;
    class NotIntTypeException extends DaseException
    {
        public $message="id不是正整形";
        public $errCode=401;
    }