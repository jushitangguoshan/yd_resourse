<?php
    namespace exception;
    class EmptyException extends DaseException
    {
        public $message="id为空";
        public $errCode=405;
    }