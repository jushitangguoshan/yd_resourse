<?php
/**
 * 模拟数据库
 * User: Jack<376927050@qq.com>
 * Date: 2019/2/20
 * Time: 15:03
 */

return [
    '1' => [
        'orderno' => 'sn123',
        'username' => 'zhangsan',
    ]
];