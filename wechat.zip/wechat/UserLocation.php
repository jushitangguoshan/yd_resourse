<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/21 0021
 * Time: 下午 7:49
 */
require_once "WxApi.php";
 class UserLocation
 {
 
     
 }